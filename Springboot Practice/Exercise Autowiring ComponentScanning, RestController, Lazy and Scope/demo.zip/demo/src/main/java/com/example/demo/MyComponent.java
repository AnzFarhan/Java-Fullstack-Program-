package com.example.demo;

public class MyComponent {

    public MyComponent(){
        System.out.println("Bean init");
    }
}

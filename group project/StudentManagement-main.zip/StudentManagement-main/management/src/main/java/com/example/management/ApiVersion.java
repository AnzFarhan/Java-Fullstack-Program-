package com.example.management.api;

public interface ApiVersion {
    String getVer();
}

package com.example.management.api.model;


public interface ApiError {

    String getCode();

    String getMessage();
}

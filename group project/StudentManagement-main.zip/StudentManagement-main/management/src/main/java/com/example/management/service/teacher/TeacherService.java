package com.example.management.service.teacher;

public interface TeacherService {
}

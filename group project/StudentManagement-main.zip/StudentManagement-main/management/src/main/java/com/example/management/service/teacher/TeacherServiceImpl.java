package com.example.management.service.teacher;

public class TeacherServiceImpl implements TeacherService{
}

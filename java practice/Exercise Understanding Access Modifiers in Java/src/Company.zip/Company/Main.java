package Company;

public class Main {
    public static void main(String[] args) {

        Manager manager = new Manager();

        manager.printDetails();
        manager.manageTeam();
        manager.increaseSalary(50);
        manager.getSalary();

    }
}
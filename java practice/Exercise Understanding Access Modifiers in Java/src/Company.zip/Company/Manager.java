package Company;

public class Manager extends Employee {

    protected void manageTeam(){//can acessing
        System.out.println("Managing Team");
    }
}

import java.util.InputMismatchException;

public class HabitatMismatchException extends Exception{
    public HabitatMismatchException(String message){
        super(message);
    }
}

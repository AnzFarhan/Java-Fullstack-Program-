public interface Domesticable {
    public boolean isFriendly();
}

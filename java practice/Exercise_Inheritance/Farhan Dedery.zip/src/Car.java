public class Car extends Vehicle {

    public void numSeats(int seats) {

    }

    public void numDoors(int doors) {

    }
}

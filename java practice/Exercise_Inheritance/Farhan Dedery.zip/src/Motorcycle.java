public class Motorcycle extends Vehicle {

    public void engineSize(int engineSize) {

    }

}

public interface Playbale {
    void play();
}

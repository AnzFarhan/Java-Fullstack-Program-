public interface MileageCalculator {

    double calculateMileage(int distance, int fuelUsed);

}

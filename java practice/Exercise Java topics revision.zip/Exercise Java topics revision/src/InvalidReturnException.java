public class InvalidReturnException extends Exception{

    public InvalidReturnException(String message) {
        super(message);
    }
}

public class SpecialBookCheckoutException extends Exception{

    public SpecialBookCheckoutException(String message) {
        super(message);
    }
}

public class Library {
    //to passed the object
    public void printDetails(Printable printable){
        //method takes a Printable object as a parameter
        printable.printDetails();
    }
}
